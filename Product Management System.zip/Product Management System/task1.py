from datetime import datetime


print('\n')
print('\t \t Welcome to My Rental Services')
print('\t \t Address: Inaruwa-5,Sunsari')
print('\n \n What do you want to do? Press the option below accordingly.')
print('\n')
print('Press 1 to rent')
print('Press 2 to return')
print('Press 3 to exit')
print('\n')

file=open('item.txt','r')
myDictionary={}
item_id=1
for line in file:
    line=line.replace('\n','')
    myDictionary[item_id]=line.split(',')
    item_id=item_id+1
#print(myDictionary)
file.close()

loop=True
while loop==True:
    inputa=(input('Enter the opreation you want to continue'))
    if inputa=='1':
        print("------------------------------------------------------------------------------------")
        print("For Bill Generation you will have to enter your details first: ")
        print("------------------------------------------------------------------------------------")
        print("\n")
        name=input("Enter your name:")
        print("\n")
        phoneNumber=int(input("Enter your phone number"))
        print("\n")
        boughtItems=[]
        more=True
        while more==True:

            print("------------------------------------------------------------------------------------")
            print("S.N. \tItem Name \t\t\tCompany Name\t\t Price\t Quantity")
            print("------------------------------------------------------------------------------------")

            file=open("item.txt","r")
            a=1
            for line in file:
                print(a,"\t"+line.replace(",","\t"))
                a=a+1
            print("------------------------------------------------------------------------------------")
            file.close()
            print("\n")

            valid_id= int(input("Please provide the id of the item you want to rent:"))
            print("\n")

            #Valid ID
            while valid_id<=0 or valid_id>len(myDictionary):
                print("Please provide a valid item ID !!!")
                print("\n")
                valid_id=int(input("Please provide the id of the item you want to rent:"))
            user_quantity= int(input("Please provide the number of quantity of the item you want to rent:"))
            print("\n")
            days=int(input("For how many days you want to rent item"))

            #Valid Quantity
            get_quantity_of_selected_item= myDictionary[valid_id][3]
            while user_quantity<=0 or user_quantity > int(get_quantity_of_selected_item):
                print("Dear Ghahak, the quantity you are looking for is not available in our shop. Please look again in the table and enter the quantity")
                print("\n")
                user_quantity= int(input("Please provide the number of quantity you want to rent:"))
                print("\n")
            
            myDictionary[valid_id][3]= int (myDictionary[valid_id][3])-int(user_quantity)
            file=open("items_details.txt","w")
            for values in myDictionary.values():
                file.write(str(values[0])+","+str(values[1])+","+str(values[2])+","+str(values[3]))
                file.write("\n")
            file.close()


            #getting user purchased items
            productName=myDictionary[valid_id][0]
            userSelectedQuantity= user_quantity
            priceOfItem= myDictionary[valid_id][2]
            priceOfSelectedItem= myDictionary[valid_id][2].replace("$",'')
            totalPrice=int(priceOfSelectedItem)*int(userSelectedQuantity)

            boughtItems.append([productName, userSelectedQuantity, priceOfItem, totalPrice])
            userRequest= input("Dear user do you want to borrow any more item? If yes press, 'Y' else press 'Enter' key.").upper()
            print("\n")
            
            if userRequest=="Y":
                more=True
            else:
                total=0
                for i in boughtItems:
                    total+int(i[3])
                grandtotal= total
                today_date_and_time = datetime.now()
                print("\n")
                print("\t \t \t \t item  Shop Bill ")
                print("\n")
                print("\t \t Kamalpokhari, Kathmandu | Phone No: 9811112255 ")
                print("\n")
                print("-------------------------------------------------------------------------")
                print("item Details are:")
                print("-------------------------------------------------------------------------")
                print("Name of the Costumer:"+str(name))
                print("Contact number: "+str(phoneNumber))
                print("Date and time of purchase: "+str(today_date_and_time))
                print("-------------------------------------------------------------------------")
                print("\n")
                print("Purchase Detail are:")
                print("------------------------------------------------------------------------------------------------------------------")
                print("Item Name \t\t Total Quantity \t\t Unit Price \t\t\tTotal")
                print("------------------------------------------------------------------------------------------------------------------")
                for i in boughtItems:
                    print(i[0],"\t\t\t",i[1],"\t\t\t",i[2],"\t\t\t","$",i[3])
                print("------------------------------------------------------------------------------------------------------------------")
                print("Grand Total: $"+str(grandtotal))
                print("Rent is for 5 days.")
                print("Note: Fine cost will added to the grand total in case of delay")
            #total_date and time= datetime.now()
                file= open(str(name)+str(phoneNumber)+".txt","w")
                file.write("\n")
                file.write("\t \t \t \t item  Shop Bill ")
                file.write("\n")
                file.write("\t \t Kamalpokhari, Kathmandu | Phone No: 9811112255 ")
                file.write("\n")
                file.write("-------------------------------------------------------------------------")
                file.write("item Details are:")
                file.write("-------------------------------------------------------------------------")
                file.write("Name of the Costumer:"+str(name))
                file.write("Contact number: "+str(phoneNumber))
                file.write("Date and time of purchase: "+str(today_date_and_time))
                file.write("-------------------------------------------------------------------------")
                file.write("\n")
                file.write("Purchase Detail are:")
                file.write("------------------------------------------------------------------------------------------------------------------")
                file.write("Item Name \t\t Total Quantity \t\t Unit Price \t\t\tTotal \n")
                file.write("------------------------------------------------------------------------------------------------------------------")
                file.write("\n")
                for i in boughtItems:
                    file.write(str(i[0])+"\t\t\t"+str(i[1])+"\t\t\t"+str(i[2])+"\t\t\t"+"$"+str(i[3]))
                    file.write("\n")
                file.write("------------------------------------------------------------------------------------------------------------------")
                file.write("Grand Total: $"+str(grandtotal))
                file.write("Rent is for 5 days.")
                file.write("Note: Fine cost will added to the grand total in case of delay")

                file.close()
                more=False
        
    elif inputa=='2':
        print('Thank you for returning')
    elif inputa=='3':
        print('The program is exit') 
    else:
        print('Error in the input')